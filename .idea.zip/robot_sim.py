import pybullet as p
import pybullet_data
import time

# 1️⃣ Connect to PyBullet
p.connect(p.GUI)  # GUI mode for visualization
p.setAdditionalSearchPath(pybullet_data.getDataPath())

# 2️⃣ Set gravity
p.setGravity(0, 0, -9.81)

# 3️⃣ Load ground plane
plane_id = p.loadURDF("plane.urdf")

# 4️⃣ Load your robot URDF
# Replace with your URDF path
robot_id = p.loadURDF("simple_biped.urdf", [0, 0, 0.5])

# 5️⃣ Simulation loop
for i in range(10000):
    p.stepSimulation()
    time.sleep(1./240.)  # 240 Hz simulation

p.disconnect()
